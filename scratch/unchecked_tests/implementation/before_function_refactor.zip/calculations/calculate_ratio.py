"""Ratio results preserve evidence and explicit missing states through storage."""
from dataclasses import dataclass, field
from decimal import Decimal, localcontext
from value_retrieval.amount import SelectionError, overlaps, uses_reported
from value_retrieval.get_value import ValueReader


@dataclass
class RatioResult:
    value: Decimal | None
    status: str
    reason: str = ''
    evidence: dict = field(default_factory=dict)

    def serializable(self):
        return dict(value=str(self.value) if self.value is not None else None,
                    status=self.status, reason=self.reason, evidence=self.evidence)


def evaluate(source, numerator, denominator, end, start=None, *, reconcile=None):
    if source is None:
        return RatioResult(None, 'missing_source', 'No financial source available')
    try:
        preferred = source.reporting_currency(end)
        currencies = [preferred] if preferred else source.currencies(end, start)
        candidates = []
        issues = set()
        availability = []
        for currency in currencies:
            reader = ValueReader(source, end, start, currency)
            top, bottom = reader.resolve(numerator), reader.resolve(denominator)
            issues.update(reader.issues)
            availability.append(dict(currency=currency, numerator_present=top is not None, denominator_present=bottom is not None))
            if top is None or bottom is None:
                continue
            checks = []
            # These checks are independent only when their derivations do not
            # reuse the reported amount they purport to verify.
            for concept, amount in ((numerator, top), (denominator, bottom)):
                if amount.evidence.get('method') != 'reported':
                    continue
                for candidate in reader.calculated(concept, (concept, )):
                    if uses_reported(candidate, concept):
                        continue
                    if not overlaps(amount, candidate):
                        raise SelectionError(f'{concept}: independent filed equation fails reconciliation')
                    checks.append(dict(check='independent_filed_equation', concept=concept,
                                       amount=candidate.serializable()))
            if reconcile is not None:
                checks.extend(reconcile(reader, top, bottom))
            issues.update(reader.issues)
            evidence = dict(numerator=top.serializable(), denominator=bottom.serializable(),
                accession=source.accession, taxonomy=source.namespace, documents=source.documents,
                reconciliation=checks, coverage_notes=sorted(issues),
                ratio_policy='28 significant decimal digits, ROUND_HALF_EVEN, disclosed point amounts')
            if bottom.value == 0:
                candidates.append(RatioResult(None, 'zero_denominator', 'Division by disclosed zero is undefined', evidence))
            else:
                with localcontext() as context:
                    context.prec = 28
                    context.rounding = 'ROUND_HALF_EVEN'
                    ratio = top.value / bottom.value
                candidates.append(RatioResult(ratio, 'available', evidence=evidence))
        if len(candidates) > 1:
            return RatioResult(None, 'ambiguous_currency', 'Multiple complete currency bases without a reporting-currency selection')
        if candidates:
            return candidates[0]
        status = 'incomplete_standard_coverage' if issues else 'missing_required_amount'
        return RatioResult(None, status, 'Required same-basis amounts were not established',
            dict(accession=source.accession, taxonomy=source.namespace, documents=source.documents,
                 currencies_considered=currencies, coverage_notes=sorted(issues),
                 numerator_requested=numerator, denominator_requested=denominator, availability=availability))
    except SelectionError as error:
        evidence = dict(accession=source.accession, taxonomy=source.namespace, documents=source.documents)
        return RatioResult(None, error.code, str(error), evidence)
