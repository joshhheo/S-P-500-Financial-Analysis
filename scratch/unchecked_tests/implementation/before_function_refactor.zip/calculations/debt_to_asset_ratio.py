"""Total liabilities divided by total assets, with balance-sheet reconciliation."""
from calculations.calculate_ratio import evaluate
from value_retrieval.amount import SelectionError, overlaps, combine, uses_reported
from value_retrieval.get_assets import ASSETS
from value_retrieval.get_liabilities import LIABILITIES
from value_retrieval.get_equity import COMBINED, INCLUSIVE, TEMPORARY


def check_balance(reader, liabilities, assets):
    checks = []
    combined = reader.direct(COMBINED)
    if combined is not None and not uses_reported(assets, COMBINED):
        if not overlaps(assets, combined):
            raise SelectionError('Assets do not reconcile to reported liabilities and equity')
        checks.append(dict(check='assets_vs_combined', amount=combined.serializable()))
    permanent, temporary = reader.resolve(INCLUSIVE), reader.resolve(TEMPORARY)
    identity = combine([(1, liabilities), (1, permanent), (1, temporary)], 'independent_balance_identity')
    if identity is not None and not uses_reported(identity, 'us-gaap:Assets'):
        if not overlaps(assets, identity):
            raise SelectionError('Liabilities and equity do not reconcile to assets')
        checks.append(dict(check='balance_identity', amount=identity.serializable()))
    return checks


def evaluate_debt_to_assets(source, period_end):
    return evaluate(source, LIABILITIES, ASSETS, period_end, reconcile=check_balance)


def calculate_debt_to_assets(source, period_end):
    result = evaluate_debt_to_assets(source, period_end)
    if result.value is None and result.reason:
        print(f'Debt/assets unavailable: {result.reason}', flush=True)
    return result.value
