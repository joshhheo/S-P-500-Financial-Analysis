"""Operating income or loss divided by total interest expense for one period."""
from calculations.calculate_ratio import evaluate, RatioResult
from value_retrieval.get_interest_expense import INTEREST_EXPENSE
from value_retrieval.get_operating_income import OPERATING_INCOME


def evaluate_interest_coverage(source, period_start, period_end):
    if period_start is None:
        return RatioResult(None, 'ambiguous_period', 'Required annual start not established')
    return evaluate(source, OPERATING_INCOME, INTEREST_EXPENSE, period_end, period_start)


def calculate_interest_coverage(source, period_start, period_end):
    result = evaluate_interest_coverage(source, period_start, period_end)
    if result.value is None and result.reason:
        print(f'Interest coverage unavailable: {result.reason}', flush=True)
    return result.value
