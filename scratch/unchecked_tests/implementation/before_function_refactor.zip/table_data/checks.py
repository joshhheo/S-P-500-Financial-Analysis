"""Validation and visible summaries at the CSV/database handoffs."""
import json
from decimal import Decimal

import pandas as pd


def check_companies(df):
    required = ["ticker", "cik", "company_name", "sector"]
    if df.empty or df[required].isna().any().any():
        raise ValueError("Company data is empty or contains missing required fields")
    if df["ticker"].duplicated().any():
        raise ValueError("Company data contains duplicate tickers")
    for column in ["ticker", "company_name", "sector"]:
        if df[column].astype(str).str.strip().eq("").any():
            raise ValueError(f"Company data contains blank {column} values")
    cik = pd.to_numeric(df["cik"], errors="raise")
    if ((cik <= 0) | (cik % 1 != 0)).any():
        raise ValueError("Company CIKs must be positive integers")
    print(f"Company data checked: {len(df)} unique tickers, "
          f"{df['cik'].nunique()} distinct CIKs, {df['sector'].nunique()} sectors", flush=True)


def check_ratios(df):
    keys = ["ticker", "fiscal_period_end"]
    if df[keys].isna().any().any() or any(df[key].astype(str).str.strip().eq("").any() for key in keys):
        raise ValueError("Financial data contains missing/blank keys")
    if df.duplicated(keys).any():
        raise ValueError("Financial data contains duplicate ticker/period keys")
    pd.to_datetime(df["fiscal_period_end"], format="%Y-%m-%d", errors="raise")
    for row in df.to_dict('records'):
        evidence = json.loads(row['extraction_evidence']) if 'extraction_evidence' in row else None
        for metric in ('debt_to_assets', 'interest_coverage'):
            value = row[metric + '_ratio']
            missing = value is None or value == '' or (isinstance(value, float) and pd.isna(value))
            number = None if missing else Decimal(str(value))
            if number is not None and not number.is_finite():
                raise ValueError(f'Nonfinite {metric}')
            status = row.get(metric + '_status')
            if status is not None and (number is not None) != (status == 'available'):
                raise ValueError(f'{metric} value/status mismatch')
            if evidence is not None:
                recorded = evidence[metric]
                recorded_value = None if recorded['value'] is None else Decimal(recorded['value'])
                if recorded_value != number or (status is not None and recorded['status'] != status):
                    raise ValueError(f'{metric} evidence mismatch')
