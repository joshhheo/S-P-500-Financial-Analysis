"""Total assets: reported or filed calculations, then defined accounting partitions."""
from value_retrieval.amount import combine, choose
from value_retrieval.get_equity import COMBINED, INCLUSIVE, TEMPORARY

ASSETS = 'us-gaap:Assets'
CURRENT = 'us-gaap:AssetsCurrent'
NONCURRENT = 'us-gaap:AssetsNoncurrent'


# Reviewed monetary instant concepts. Component tags require a filed equation;
# this list is not a formula and its members must never simply be summed.
SUPPORTED_CONCEPTS = {ASSETS, CURRENT, NONCURRENT} | {
    'us-gaap:Cash',
    'us-gaap:CashAndCashEquivalentsAtCarryingValue',
    'us-gaap:AccountsReceivableNetCurrent',
    'us-gaap:DeferredIncomeTaxAssetsNet',
    'us-gaap:EquityMethodInvestments',
    'us-gaap:FinanceLeaseRightOfUseAsset',
    'us-gaap:FiniteLivedIntangibleAssetsNet',
    'us-gaap:Goodwill',
    'us-gaap:IntangibleAssetsNetExcludingGoodwill',
    'us-gaap:LongTermInvestments',
    'us-gaap:OperatingLeaseRightOfUseAsset',
    'us-gaap:OtherAssetsNoncurrent',
    'us-gaap:PropertyPlantAndEquipmentNet',
}


def asset_fallback(reader, concept, trail, role):
    candidates = reader.calculated(concept, trail, role)
    partition = combine([(1, reader.resolve(CURRENT, trail, role)),
                         (1, reader.resolve(NONCURRENT, trail, role))],
                        dict(kind='defined_partition', target=ASSETS))
    if partition is not None:
        candidates.append(partition)
    if role is not None:
        return choose(candidates, ASSETS)

    independent = reader.direct(COMBINED)
    if independent is None:
        combined = reader.resolve(COMBINED, trail)
        if combined is not None:
            candidates.append(combined)
    identity = combine([(1, reader.resolve('us-gaap:Liabilities', trail)),
                        (1, reader.resolve(INCLUSIVE, trail)),
                        (1, reader.resolve(TEMPORARY, trail))],
                       'assets_equals_liabilities_plus_permanent_and_temporary_equity')
    if identity is not None:
        candidates.append(identity)
    return choose(candidates, ASSETS, independent)


def get_assets(source, period_end):
    from value_retrieval.get_value import get_value
    return get_value(source, ASSETS, period_end)
