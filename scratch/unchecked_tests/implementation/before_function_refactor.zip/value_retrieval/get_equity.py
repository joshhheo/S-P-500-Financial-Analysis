"""Permanent and temporary equity definitions and balance-sheet scope checks."""
from value_retrieval.amount import combine, overlaps, choose

INCLUSIVE = 'us-gaap:StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'
TEMPORARY = 'us-gaap:TemporaryEquityCarryingAmountIncludingPortionAttributableToNoncontrollingInterests'
PARENT_TEMPORARY = 'us-gaap:TemporaryEquityCarryingAmountAttributableToParent'
REDEEMABLE = 'us-gaap:RedeemableNoncontrollingInterestEquityCarryingAmount'
COMBINED = 'us-gaap:LiabilitiesAndStockholdersEquity'
CAPTION = 'us-gaap:CommitmentsAndContingencies'
PARENT = 'us-gaap:StockholdersEquity'
MINORITY = 'us-gaap:MinorityInterest'

EQUITY_BRANCHES = {name.removeprefix('us-gaap:') for name in
                   (PARENT, MINORITY, INCLUSIVE, TEMPORARY, PARENT_TEMPORARY, REDEEMABLE)}


SUPPORTED_CONCEPTS = {
    INCLUSIVE, TEMPORARY, PARENT_TEMPORARY, REDEEMABLE, COMBINED, CAPTION,
    PARENT, MINORITY,
}


def equity_fallback(reader, concept, trail, role):
    candidates = reader.calculated(concept, trail, role)
    components = (PARENT, MINORITY) if concept == INCLUSIVE else (PARENT_TEMPORARY, REDEEMABLE)
    result = combine([(1, reader.resolve(name, trail, role)) for name in components],
                     dict(kind='defined_partition', target=concept))
    if result is not None:
        candidates.append(result)
    return choose(candidates, concept)


def equation_applies(reader, parent, children):
    """Exclude a combined-total equation contradicted by disclosed equity scope."""
    names = {name for name, _ in children}
    if parent == COMBINED:
        if PARENT in names and INCLUSIVE not in names and MINORITY not in names:
            minority = reader.direct(MINORITY)
            inclusive = reader.direct(INCLUSIVE)
            parent_equity = reader.direct(PARENT)
            different_permanent_scope = (inclusive is not None and parent_equity is not None
                                         and not overlaps(inclusive, parent_equity))
            if (minority is not None and minority.value != 0) or different_permanent_scope:
                reader.issues.add('inapplicable_parent_equity_equation')
                return False
        if not {TEMPORARY, PARENT_TEMPORARY, REDEEMABLE}.intersection(names):
            temporary = reader.direct(TEMPORARY)
            redeemable = reader.direct(REDEEMABLE)
            parent_temporary = reader.direct(PARENT_TEMPORARY)
            if any(a is not None and a.value != 0 for a in (temporary, redeemable, parent_temporary)):
                reader.issues.add('inapplicable_temporary_equity_equation')
                return False
    return True


def get_equity(source, period_end):
    """Return permanent and temporary equity separately; missing is not zero."""
    from value_retrieval.get_value import get_value
    return get_value(source, INCLUSIVE, period_end), get_value(source, TEMPORARY, period_end)
