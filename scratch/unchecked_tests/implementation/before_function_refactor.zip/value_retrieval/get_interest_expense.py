"""Total interest expense; net or nonoperating interest alone is not a substitute."""
from value_retrieval.amount import combine, choose

INTEREST_EXPENSE = 'us-gaap:InterestExpense'
OPERATING = 'us-gaap:InterestExpenseOperating'
NONOPERATING = 'us-gaap:InterestExpenseNonoperating'
INTEREST_INCOME = 'us-gaap:InterestIncomeOperating'
NET_INTEREST = 'us-gaap:InterestIncomeExpenseNet'


# The operating/nonoperating expense concepts first appear in US GAAP 2024.
CONCEPTS_FROM_2024 = {OPERATING, NONOPERATING}
SUPPORTED_CONCEPTS = {
    INTEREST_EXPENSE, OPERATING, NONOPERATING, INTEREST_INCOME, NET_INTEREST,
    'us-gaap:FinanceLeaseInterestExpense',
    'us-gaap:InterestCostsIncurred',
    'us-gaap:InterestCostsCapitalized',
}


def interest_fallback(reader, concept, trail, role):
    candidates = reader.calculated(concept, trail, role)
    if concept == INTEREST_EXPENSE:
        components = [(1, OPERATING), (1, NONOPERATING)]
    else:
        components = [(1, INTEREST_INCOME), (-1, NET_INTEREST)]
    result = combine([(weight, reader.resolve(name, trail, role))
                      for weight, name in components],
                     dict(kind='defined_partition', target=concept))
    if result is not None:
        candidates.append(result)
    return choose(candidates, concept)


def get_interest_expense(source, period_start, period_end):
    from value_retrieval.get_value import get_duration_value
    return get_duration_value(source, INTEREST_EXPENSE, period_start, period_end)
