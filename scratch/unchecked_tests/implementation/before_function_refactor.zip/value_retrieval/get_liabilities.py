"""Total liabilities and the reviewed liability branches of a balance sheet."""
from value_retrieval.amount import Amount, SelectionError, combine, choose, overlaps, uses_reported
from value_retrieval.get_equity import (
    COMBINED, INCLUSIVE, TEMPORARY, PARENT_TEMPORARY, REDEEMABLE, EQUITY_BRANCHES,
)

P = 'us-gaap:'
LIABILITIES = P + 'Liabilities'
CURRENT = P + 'LiabilitiesCurrent'
NONCURRENT = P + 'LiabilitiesNoncurrent'

LIABILITY_BRANCHES = {
    'Liabilities', 'LiabilitiesCurrent', 'LiabilitiesNoncurrent', 'LongTermDebtNoncurrent',
    'OperatingLeaseLiabilityNoncurrent', 'FinanceLeaseLiabilityNoncurrent',
    'DeferredIncomeTaxLiabilitiesNet', 'DeferredIncomeTaxesAndOtherLiabilitiesNoncurrent',
    'OtherLiabilitiesNoncurrent', 'AccountsPayableCurrent', 'DeferredRevenueNoncurrent',
}


# Extra components may participate in filed equations; they do not expand the
# separately reviewed balance-sheet branch partition above.
SUPPORTED_CONCEPTS = {P + name for name in LIABILITY_BRANCHES} | {
    'us-gaap:AccruedIncomeTaxesNoncurrent',
    'us-gaap:ContractWithCustomerLiabilityNoncurrent',
}


def liability_fallback(reader, concept, trail, role):
    candidates = reader.calculated(concept, trail, role)
    partition = combine([(1, reader.resolve(CURRENT, trail, role)),
                         (1, reader.resolve(NONCURRENT, trail, role))],
                        dict(kind='defined_partition', target=LIABILITIES))
    if partition is not None:
        candidates.append(partition)
    if role is not None:
        return choose(candidates, LIABILITIES)

    candidates.extend(balance_liabilities(reader, trail))
    identity = combine([(1, reader.resolve('us-gaap:Assets', trail)),
                        (-1, reader.resolve(INCLUSIVE, trail)),
                        (-1, reader.resolve(TEMPORARY, trail))],
                       'liabilities_equals_assets_less_permanent_and_temporary_equity')
    if identity is not None:
        candidates.append(identity)
    return choose(candidates, LIABILITIES)


def balance_liabilities(reader, trail=()):
    total = reader.direct(COMBINED)
    if total is None:
        return []
    candidates = []
    for (role, parent), children in reader.source.equations.items():
        if parent != COMBINED or not reader.eligible(parent, children):
            continue
        names = {c for c, _ in children}
        # A total and one of its parts are not disjoint liability branches.
        if P+'Liabilities' in names:
            continue  # generic one-unknown inverse handles the valid total branch
        if INCLUSIVE in names and names.intersection({P+'StockholdersEquity', P+'MinorityInterest'}):
            continue
        if TEMPORARY in names and names.intersection({PARENT_TEMPORARY, REDEEMABLE}):
            continue
        noncurrent_parts = {P+n for n in LIABILITY_BRANCHES if n not in
                            {'Liabilities', 'LiabilitiesCurrent', 'LiabilitiesNoncurrent', 'AccountsPayableCurrent'}}
        if ((P+'LiabilitiesNoncurrent' in names and names.intersection(noncurrent_parts))
                or {P+'LiabilitiesCurrent', P+'AccountsPayableCurrent'}.issubset(names)):
            reader.issues.add('overlapping_liability_branches')
            continue
        parts, liabilities, equity = [], [], []
        for child, weight in children:
            if reader.is_caption(child):
                continue
            name = child.removeprefix(P)
            if name not in LIABILITY_BRANCHES | EQUITY_BRANCHES or weight != 1:
                reader.issues.add('unreviewed_balance_branch')
                break
            amount = reader.resolve(child, trail, role)
            if amount is None:
                break
            parts.append((weight, amount))
            (liabilities if name in LIABILITY_BRANCHES else equity).append((weight, amount))
        else:
            if liabilities and equity:
                whole = combine(parts, 'filed_combined_total_check')
                if not overlaps(total, whole):
                    raise SelectionError('Combined balance-sheet equation fails independent reconciliation')
                result = combine(liabilities, dict(kind='filed_liability_partition', role=role))
                candidates.append(Amount(result.value, result.unit, result.period, result.lower, result.upper,
                    dict(method='reconciled_liability_partition', derivation=result.serializable(),
                         reported_combined=total.serializable(), combined_check=whole.serializable(),
                         check_is_independent=not uses_reported(whole, COMBINED))))
    return candidates


def get_liabilities(source, period_end):
    from value_retrieval.get_value import get_value
    return get_value(source, LIABILITIES, period_end)
