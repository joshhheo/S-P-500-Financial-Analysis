"""Operating income or loss; use the reported concept or its filed calculation."""
OPERATING_INCOME = 'us-gaap:OperatingIncomeLoss'


# These are duration concepts usable through a complete filed equation only.
# Pretax, investment and nonoperating amounts are not operating-income aliases.
SUPPORTED_CONCEPTS = {OPERATING_INCOME} | {
    'us-gaap:Revenues',
    'us-gaap:RevenueFromContractWithCustomerExcludingAssessedTax',
    'us-gaap:CostOfRevenue',
    'us-gaap:GrossProfit',
    'us-gaap:OperatingExpenses',
    'us-gaap:GeneralAndAdministrativeExpense',
    'us-gaap:ResearchAndDevelopmentExpense',
    'us-gaap:SellingAndMarketingExpense',
    'us-gaap:NonoperatingIncomeExpense',
    'us-gaap:OtherNonoperatingIncomeExpense',
    'us-gaap:ForeignCurrencyTransactionGainLossBeforeTax',
    'us-gaap:GainLossOnDerivativeInstrumentsNetPretax',
    'us-gaap:GainLossOnInvestments',
    'us-gaap:InvestmentIncomeInterestAndDividend',
    'us-gaap:InvestmentIncomeNet',
    'us-gaap:IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest',
    'us-gaap:IncomeLossFromContinuingOperationsBeforeIncomeTaxesMinorityInterestAndIncomeLossFromEquityMethodInvestments',
}


def get_operating_income(source, period_start, period_end):
    from value_retrieval.get_value import get_duration_value
    return get_duration_value(source, OPERATING_INCOME, period_start, period_end)
