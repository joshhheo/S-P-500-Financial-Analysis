"""Shared fact selection and filed calculation traversal.

Accounting fallbacks live in the individual metric modules. Those modules import
this reader only inside public getters to avoid circular module imports.
"""
from value_retrieval.source import period_type
from value_retrieval.amount import Amount, SelectionError, choose, combine, reported_selection
from value_retrieval.get_assets import ASSETS, asset_fallback
from value_retrieval.get_liabilities import LIABILITIES, liability_fallback
from value_retrieval.get_equity import INCLUSIVE, TEMPORARY, CAPTION, equity_fallback, equation_applies
from value_retrieval.get_interest_expense import INTEREST_EXPENSE, OPERATING, interest_fallback

FALLBACKS = {
    ASSETS: asset_fallback,
    LIABILITIES: liability_fallback,
    INCLUSIVE: equity_fallback,
    TEMPORARY: equity_fallback,
    INTEREST_EXPENSE: interest_fallback,
    OPERATING: interest_fallback,
}


class ValueReader:
    def __init__(self, source, end, start=None, currency=None):
        self.source = source
        self.end, self.start = end, start
        self.currency = currency
        self.period = (self.source.cik, start, end)
        self._reported = {}
        self.issues = set()

    def rows(self, concept):
        return [r for r in self.source.records if r['concept'] == concept
                and not r['is_dimensioned'] and r['entity_identifier'] == self.source.cik
                and ((self.start is None and r['period_instant'] == self.end)
                     or (self.start is not None and r['period_start'] == self.start and r['period_end'] == self.end))]

    def direct(self, concept):
        if concept in self._reported:
            return self._reported[concept]
        expected = 'instant' if self.start is None else 'duration'
        if period_type(concept, self.source.year) != expected:
            self.issues.add('unsupported_concept_or_period')
            return None
        rows = []
        relevant = self.rows(concept)
        for row in relevant:
            if row.get('nil') or row['value'] == '':
                continue
            unit = self.source.units.get(row['unit_ref'])
            if unit is None:
                raise SelectionError(f'{concept}: monetary unit cannot be resolved', 'incompatible_basis')
            if self.currency and unit != self.currency:
                continue
            rows.append(dict(row, unit_ref=unit))
        if not rows:
            self._reported[concept] = None
            return None
        if any(r.get('nil') and self.source.units.get(r['unit_ref']) == rows[0]['unit_ref'] for r in relevant):
            raise SelectionError(f'{concept}: nil and numeric duplicates conflict')
        value, lower, upper = reported_selection(rows, concept, self.end)
        evidence = dict(method='reported', concept=concept, taxonomy=self.source.namespace,
            accession=self.source.accession, occurrences=[dict(context=r['context_ref'],
                fact_id=r.get('fact_id'), value=r['value'], decimals=r.get('decimals')) for r in rows])
        amount = Amount(value, rows[0]['unit_ref'], self.period, lower, upper, evidence)
        self._reported[concept] = amount
        return amount

    def is_caption(self, concept):
        rows = self.rows(concept)
        return concept == CAPTION and bool(rows) and all(r.get('nil') and r['value'] == '' for r in rows)

    def eligible(self, parent, children):
        if self.source.calculation_issue:
            self.issues.add('unsupported_calculation_structure')
            return False
        names = [name for name, _ in children]
        if len(names) != len(set(names)):
            self.issues.add('duplicate_relationship')
            return False
        expected = 'instant' if self.start is None else 'duration'
        if (period_type(parent, self.source.year) != expected
                or any(weight not in (-1, 1) or period_type(name, self.source.year) != expected
                       for name, weight in children)):
            self.issues.add('unsupported_calculation_component')
            return False
        return equation_applies(self, parent, children)

    def calculated(self, concept, trail=(), role=None):
        candidates = []
        for (network, parent), children in self.source.equations.items():
            if role is not None and network != role:
                continue
            if parent != concept and not any(child == concept for child, _ in children):
                continue
            if not self.eligible(parent, children):
                continue
            if parent == concept:
                parts = []
                for child, weight in children:
                    if self.is_caption(child):
                        continue
                    amount = self.resolve(child, trail, network)
                    if amount is None:
                        break
                    parts.append((weight, amount))
                else:
                    result = combine(parts, dict(kind='filed_forward', role=network, parent=parent))
                    if result:
                        candidates.append(result)
            elif any(child == concept for child, _ in children):
                # One-unknown rearrangement: the parent must be independently reported.
                total = self.direct(parent)
                if total is None:
                    continue
                parts = [(1, total)]
                target_weight = next(w for c, w in children if c == concept)
                for child, weight in children:
                    if child == concept or self.is_caption(child):
                        continue
                    amount = self.resolve(child, trail, network)
                    if amount is None:
                        break
                    parts.append((-weight, amount))
                else:
                    result = combine([(w*target_weight, a) for w, a in parts],
                                     dict(kind='filed_inverse', role=network, parent=parent, target=concept))
                    if result:
                        candidates.append(result)
        return candidates

    def resolve(self, concept, trail=(), role=None):
        reported = self.direct(concept)
        if reported is not None:
            return reported
        if concept == CAPTION or concept in trail:
            return None
        if len(trail) > 30:
            self.issues.add('calculation_depth_limit')
            return None
        trail = trail + (concept, )
        fallback = FALLBACKS.get(concept)
        if fallback is not None:
            return fallback(self, concept, trail, role)
        return choose(self.calculated(concept, trail, role), concept)


def retrieve(source, concept, end, start=None, *, reported_only=False, calculated_only=False):
    if source is None:
        return None
    preferred = source.reporting_currency(end)
    currencies = [preferred] if preferred else source.currencies(end, start)
    amounts = []
    for currency in currencies:
        reader = ValueReader(source, end, start, currency)
        if reported_only:
            amount = reader.direct(concept)
        elif calculated_only:
            amount = choose(reader.calculated(concept, (concept, )), concept)
        else:
            amount = reader.resolve(concept)
        if amount is not None:
            amounts.append(amount)
    if len(amounts) > 1:
        raise SelectionError('Multiple currencies available; reporting currency is not established', 'ambiguous_currency')
    return amounts[0] if amounts else None


def normalize_concept_name(concept):
    return concept.replace('us-gaap_', 'us-gaap:', 1) if concept.startswith('us-gaap_') else concept


def get_reported_value(financial_data, concept, period_end, period_start=None):
    result = retrieve(financial_data, concept, period_end, period_start, reported_only=True)
    return result.value if result is not None else None


def get_calculated_value(financial_data, concept, period_end, period_start=None):
    result = retrieve(financial_data, concept, period_end, period_start, calculated_only=True)
    return result.value if result is not None else None


def get_value(financial_data, concept, period_end, period_start=None):
    result = retrieve(financial_data, concept, period_end, period_start)
    return result.value if result is not None else None


def get_instant_value(financial_data, concept, period_end):
    return get_value(financial_data, concept, period_end)


def get_duration_value(financial_data, concept_name, period_start, period_end):
    if period_start is None or period_end is None:
        return None
    return get_value(financial_data, concept_name, period_end, period_start)
